package model;

public class User extends BaseEntity {
    public User(int id, int parentId) {
        super(id, parentId);
    }
}
