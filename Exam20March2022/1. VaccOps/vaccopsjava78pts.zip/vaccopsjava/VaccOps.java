package vaccopsjava;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class VaccOps implements IVaccOps {

    private Map<String, Doctor> doctorsByNames;
    private Map<String, List<Patient>> doctorsWithPatients;
    private Map<String, Patient> patientsByNames;


    public VaccOps() {
        this.doctorsByNames = new HashMap<>();
        this.doctorsWithPatients = new HashMap<>();
        this.patientsByNames = new HashMap<>();

    }

       public void addDoctor(Doctor d) {
        if (doctorsByNames.containsKey(d.name)) {
            throw new IllegalArgumentException();
        }
        this.doctorsByNames.put(d.name, d);
        doctorsWithPatients.put(d.name, new ArrayList<>());
    }

    public void addPatient(Doctor d, Patient p) {
        if (exist(p) || !exist(d)) {
            throw new IllegalArgumentException();
        }

        patientsByNames.put(p.name, p);
        doctorsWithPatients.get(d.name).add(p);

    }


    public Collection<Doctor> getDoctors() {
        return this.doctorsByNames.values();
    }

    public Collection<Patient> getPatients() {
        return this.patientsByNames.values();
    }

    public boolean exist(Doctor d) {
        return this.doctorsByNames.containsKey(d.name);
    }

    public boolean exist(Patient p) {
        return this.patientsByNames.containsKey(p.name);
    }


    public Doctor removeDoctor(String name) {
        Doctor doctor = this.doctorsByNames.values().stream().filter(d -> d.name.equals(name)).findFirst().orElse(null);
        if (doctor == null) {
            throw new IllegalArgumentException();
        }
        Doctor removedDoctor = doctorsByNames.remove(doctor.name);
        List<Patient> removedPatients = doctorsWithPatients.remove(doctor.name);
        /*  removedPatients.forEach(patient -> patientsByNames.remove(patient.name));*/
        return removedDoctor;
    }


    public void changeDoctor(Doctor from, Doctor to, Patient p) {
        if (!exist(from) || !exist(to) || !exist(p)) {
            throw new IllegalArgumentException();
        }

        doctorsWithPatients.get(from.name).remove(p);
        patientsByNames.remove(p.name);

        addPatient(to, p);
    }

    public Collection<Doctor> getDoctorsByPopularity(int popularity) {
        return getDoctors()
                .stream().filter(d -> d.popularity == popularity).collect(Collectors.toList());
    }

    public Collection<Patient> getPatientsByTown(String town) {
        return getPatients()
                .stream().filter(p -> p.town.equals(town)).collect(Collectors.toList());
    }

    public Collection<Patient> getPatientsInAgeRange(int lo, int hi) {
        return getPatients()
                .stream().filter(p -> p.age >= lo && p.age <= hi).collect(Collectors.toList());
    }

    public Collection<Doctor> getDoctorsSortedByPatientsCountDescAndNameAsc() {
        return getDoctors().stream().sorted((d1, d2) -> {
            int firstBarberClients = this.doctorsWithPatients.get(d1.name).size();
            int secondBarberClients = this.doctorsWithPatients.get(d2.name).size();
            int result = Integer.compare(secondBarberClients, firstBarberClients);

            if (result == 0) {
                result = d1.name.compareTo(d2.name);
            }


            return result;

        }).collect(Collectors.toList());
    }


    public Collection<Patient> getPatientsSortedByDoctorsPopularityAscThenByHeightDescThenByAge() {
//        return getPatients().stream().sorted((p1, p2) -> {
//            List<Doctor> collect = getDoctors().stream().sorted((d1, d2) -> {
//                int result = Integer.compare(d1.popularity, d2.popularity);
//
//                if (result == 0) {
//                    result = Integer.compare(p2.height, p1.height);
//                    if (result == 0) {
//                        result = Integer.compare(p1.age, p2.age);
//                    }
//                }
//                return result;
//            }).collect(Collectors.toList());
        return null;
   }
}

