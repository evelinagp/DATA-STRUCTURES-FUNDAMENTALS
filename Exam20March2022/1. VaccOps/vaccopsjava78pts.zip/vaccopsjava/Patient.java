package vaccopsjava;

public class Patient {

    public String name;
    public int height;
    public int age;
    public String town;

    public Patient(String name, int height, int age, String town) {
        this.name = name;
        this.height = height;
        this.age = age;
        this.town = town;
    }
}
