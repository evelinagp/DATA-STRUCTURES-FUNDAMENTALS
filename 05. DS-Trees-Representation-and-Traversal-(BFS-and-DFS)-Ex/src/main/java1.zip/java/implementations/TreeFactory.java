package implementations;

import java.util.LinkedHashMap;
import java.util.Map;

public class TreeFactory {
    private Map<Integer, Tree<Integer>> nodesByKeys;

    public TreeFactory() {
        this.nodesByKeys = new LinkedHashMap<>();
    }

    public Tree<Integer> createTreeFromStrings(String[] input) {
        return null;
    }

    private Tree<Integer> getRoot() {
        return null;
    }

    public Tree<Integer> createNodeByKey(int key) {
        return null;
    }

    public void addEdge(int parent, int child) {

    }
}



