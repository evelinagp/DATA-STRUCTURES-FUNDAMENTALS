package implementations;

import interfaces.AbstractTree;

import java.util.*;
import java.util.stream.Collectors;

public class Tree<E> implements AbstractTree<E> {

    private E key;
    private Tree<E> parent;
    private List<Tree<E>> children;

    public Tree(E key, Tree<E>... children) {
        this.key = key;
        this.children = new ArrayList<>();
        for (Tree<E> child : children) {
            child.setParent(this);
            this.children.add(child);
        }
    }


    @Override
    public void setParent(Tree<E> parent) {
        this.parent = parent;

    }

    @Override
    public void addChild(Tree<E> child) {
        this.children.add(child);
    }

    @Override
    public Tree<E> getParent() {
        return this.parent;

    }

    @Override
    public E getKey() {
        return this.key;
    }

    @Override
    public String getAsString() {
        StringBuilder stringBuilder = new StringBuilder();
        traverseTreeWithRecurrence(stringBuilder, 0, this);
        return stringBuilder.toString().trim();
    }

    private void traverseTreeWithRecurrence(StringBuilder stringBuilder, int indent, Tree<E> tree) {
        stringBuilder
                .append(this.getPadding(indent))
                .append(tree.getKey())
                .append(System.lineSeparator());

        for (Tree<E> child : tree.children) {
            traverseTreeWithRecurrence(stringBuilder, indent + 2, child);
        }

    }

    private String getPadding(int size) {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < size; i++) {
            builder.append(" ");
        }
        return builder.toString();
    }

    @Override
    public List<E> getLeafKeys() {
        return traverseTreeWithBFS()
                .stream().filter(tree -> tree.children.size() == 0)
                .map(Tree::getKey).collect(Collectors.toList());

    }

    private List<Tree<E>> traverseTreeWithBFS() {
        StringBuilder sb = new StringBuilder();

        Deque<Tree<E>> queue = new ArrayDeque<>();
        queue.offer(this);

        int indent = 0;
        List<Tree<E>> allNodes = new ArrayList<>();

        while (!queue.isEmpty()) {
            Tree<E> tree = queue.poll();
            allNodes.add(tree);
            for (Tree<E> child : tree.children) {
                queue.offer(child);
            }

        }
        return allNodes;
    }

    @Override
    public List<E> getMiddleKeys() {
        return null;
    }

    @Override
    public Tree<E> getDeepestLeftmostNode() {
        return null;
    }

    @Override
    public List<E> getLongestPath() {
        return null;
    }

    @Override
    public List<List<E>> pathsWithGivenSum(int sum) {

     /*
     import data_structures.Tree;
import tree_lib.ReadTree;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader consoleReader = new BufferedReader(new InputStreamReader(System.in));

        Map<Integer, Tree<Integer>> treeMap = new HashMap<>();

        Tree<Integer> root = ReadTree.readTreeMapFromConsole(treeMap, consoleReader);
        Integer targetSum = Integer.parseInt(consoleReader.readLine());

        consoleReader.close();

        System.out.println("Paths of sum " + targetSum + ":");
        System.out.println(getPathsOfSum(root, targetSum));
    }

    private static String getPathsOfSum(Tree<Integer> root, Integer targetSum) {
        StringBuilder result = new StringBuilder();
        List<Tree<Integer>> treeList = new ArrayList<>();

        dfsPathsOfSum(root, treeList, targetSum);

        for (int i = 0; i < treeList.size(); i++) {
            result.append(getTreeValuesToRoot(treeList.get(i))).append(System.lineSeparator());
        }

        return result.toString().trim();
    }

    private static void dfsPathsOfSum(Tree<Integer> currentTree, List<Tree<Integer>> treeList, Integer targetSum) {
        for (Tree<Integer> childTree : currentTree.getChildren()) {
            dfsPathsOfSum(childTree, treeList, targetSum);
        }

        if (currentTree.getChildren().isEmpty()) {
            if (getValuesSumUpToRoot(currentTree) == targetSum) {
                treeList.add(currentTree);
            }
        }
    }

    private static int getValuesSumUpToRoot(Tree<Integer> tree) {
        int result = 0;
        while (tree != null) {
            result += tree.getValue();
            tree = tree.getParentTree();
        }

        return result;
    }

    private static String getTreeValuesToRoot(Tree<Integer> tree) {
        Deque<String> stack = new ArrayDeque<>();

        while (tree != null) {
            stack.push(tree.getValue().toString());
            tree = tree.getParentTree();
        }

        return String.join(" ", stack);
    }
}
      */
        return null;
    }

    @Override
    public List<Tree<E>> subTreesWithGivenSum(int sum) {
        /*

import data_structures.Tree;
import tree_lib.ReadTree;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader consoleReader = new BufferedReader(new InputStreamReader(System.in));

        Tree<Integer> root = ReadTree.readTreeMapFromConsole(new HashMap<>(), consoleReader);
        Integer targetedSubtreeSum = Integer.parseInt(consoleReader.readLine());

        consoleReader.close();

        Iterable<Tree<Integer>> treesInPreorder = getTreesInPreorder(root);
        System.out.println("Subtrees of sum " + targetedSubtreeSum + ":");
        for (Tree<Integer> currentTree : treesInPreorder) {
            Iterable<Integer> preorderValues = currentTree.preOrderValues();
            if (getSum(preorderValues) == targetedSubtreeSum) {
                System.out.println(join(" ", preorderValues));
            }
        }
    }

    private static Iterable<Tree<Integer>> getTreesInPreorder(Tree<Integer> tree) {
        List<Tree<Integer>> result = new ArrayList<>();

        preorder(result, tree);

        return result;
    }

    private static void preorder(List<Tree<Integer>> treeList, Tree<Integer> currentTree) {
        treeList.add(currentTree);

        for (Tree<Integer> childTree : currentTree.getChildren()) {
            preorder(treeList, childTree);
        }
    }


    private static int getSum(Iterable<Integer> values) {
        int result = 0;

        for (Integer value : values) {
            result += value;
        }

        return result;
    }

    private static String join(String delimiter, Iterable<Integer> iterable) {
        StringBuilder sb = new StringBuilder();
        for (Integer element: iterable) {
            sb.append(element).append(delimiter);
        }

        return sb.toString().substring(0, sb.lastIndexOf(delimiter));
    }
}
         */
        return null;
    }
}



