package tripadministratorjava;

public class Company {

    public String name;
    public int tripOrganizationLimit;

    public Company(String name, int tripOrganizationLimit) {
        this.name = name;
        this.tripOrganizationLimit = tripOrganizationLimit;
    }
}
